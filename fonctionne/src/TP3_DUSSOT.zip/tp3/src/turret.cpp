#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64MultiArray.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/TransformStamped.h>
#include "visualization_msgs/Marker.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include "tf/tf.h"
#include <cmath>
#include <array>

double u = 0.0;
using namespace std;
geometry_msgs::TransformStamped transform_vect;

void Euler(vector<double> &x){
  double dt = 1.0/25.0; //essayer de mettre le même temps pour avoir une simulation en temps réel, entre le noeud et Euler
  double v = 1.0;

  x[0] += v * cos(x[2]) * dt + 4.5;
  x[1] += v * sin(x[2]) * dt;

  x[2] += u * dt;
  x[2] = 2.0*atan(tan(x[2]*0.5));
}

void chatter_callback(const geometry_msgs::Twist::ConstPtr &msg)
{
  u = msg->angular.z;
  ROS_INFO("dtheta = %f", msg->angular.z);
}

void transform_callback(const geometry_msgs::TransformStamped::ConstPtr &msg)
{
  transform_vect.transform.translation.x = msg->transform.translation.x + 4.5;
  transform_vect.transform.translation.y = msg->transform.translation.y;
  transform_vect.transform.translation.z = msg->transform.translation.z;

  transform_vect.transform.rotation.x = msg->transform.rotation.x;
  transform_vect.transform.rotation.y = msg->transform.rotation.y;
  transform_vect.transform.rotation.z = msg->transform.rotation.z;
  transform_vect.transform.rotation.w = msg->transform.rotation.w;
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "tourelle");
  ros::NodeHandle nh;

  ros::Publisher chatter_pub = nh.advertise<geometry_msgs::PoseStamped>("Turret_pos", 1000);
  ros::Subscriber sub = nh.subscribe("Control", 10, chatter_callback);
  ros::Subscriber transform_pub = nh.subscribe("broadcast_tf", 10, transform_callback);

  ros::Rate loop_rate(25);
  vector<double> x = {0.0,0.0,0.0};

  geometry_msgs::PoseStamped msg;
  msg.header.frame_id = "map";
  tf::Quaternion q;

  nh.param<double>("position_x", x[0], 0.0);
  nh.param<double>("position_y", x[1], 0.0);
  std::string ns = ros::this_node::getNamespace();
  ros::Publisher vis_pub = nh.advertise<visualization_msgs::Marker>( "visualization_marker_turret", 0 );
  visualization_msgs::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = ns;
  marker.id = 0;
  marker.type = visualization_msgs::Marker::MESH_RESOURCE;
  marker.action = visualization_msgs::Marker::ADD;

  marker.scale.x = 1;
  marker.scale.y = 1;
  marker.scale.z = 1;
  marker.color.a = 1.0; // alpha = transparence
  marker.color.r = 1.0;
  marker.color.g = 1.0;
  marker.color.b = 1.0;
  marker.mesh_resource = "package://tp3/meshs/turret.dae";

  while (ros::ok())
  {

    Euler(x);
    //printf("en dehors : %f\n",x[2]);

    msg.pose.position.x = x[0];          //publi x y
    msg.pose.position.y = x[1];
    msg.pose.position.z = 0;
    q.setRPY(0,0,x[2]);
    tf::quaternionTFToMsg(q,msg.pose.orientation); //publi orientation sous forme quaternion
    msg.header.stamp = ros::Time::now();
    //////
    marker.pose = msg.pose;
    //////
    chatter_pub.publish(msg);
    vis_pub.publish( marker );

    ros::spinOnce();

    loop_rate.sleep();
  }

  return 0;
}
