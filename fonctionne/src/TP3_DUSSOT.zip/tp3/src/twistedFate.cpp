#include <ros/ros.h>
#include "tf/tf.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <std_msgs/String.h>

int main(int argc, char** argv) {
  ros::init(argc, argv, "char_simulator");
  ros::NodeHandle nh;

  for (int i=0; i<6; i++){
    printf("argv = %s\n", argv[i]);
  }

  float x=atof(argv[1]), y=0, z=0;
  float yaw=0, pitch=0, roll=0;

  // Création d’un object permettant de publier des tf
  tf2_ros::TransformBroadcaster br;

  // Message pour la transmission sur le canal
  geometry_msgs::TransformStamped transformStamped;
  // Définition de la relation entre les repères
  transformStamped.header.frame_id = argv[7];
  transformStamped.child_frame_id = argv[8];
  ros::Rate rate(10.0);
  while (nh.ok()){
    // Date de la transformée
    transformStamped.header.stamp = ros::Time::now();
    // Définition de la translation
    transformStamped.transform.translation.x = x;
    transformStamped.transform.translation.y = y;
    transformStamped.transform.translation.z = z;
    // Définition de la rotation
    tf2::Quaternion q;
    q.setRPY(roll, pitch, yaw);

    transformStamped.transform.rotation.x = q.getX();
    transformStamped.transform.rotation.y = q.getY();
    transformStamped.transform.rotation.z = q.getZ();
    transformStamped.transform.rotation.w = q.getW();
    br.sendTransform(transformStamped);
    rate.sleep();
  }
}
