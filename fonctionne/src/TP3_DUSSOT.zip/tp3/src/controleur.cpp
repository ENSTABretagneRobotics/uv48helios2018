#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64MultiArray.h"
#include "geometry_msgs/PoseStamped.h"
#include "visualization_msgs/Marker.h"
#include "tf/tf.h"
#include <cmath>
#include <array>

double q=0.0;
double theta=0.0;
double x=0.0;
double y=0.0;
double K=1.0;

void chatter_callback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
  theta = tf::getYaw(msg->pose.orientation); // Quaternion à convertir

  x = msg->pose.position.x;
  y = msg->pose.position.y;

}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "controleur");
  ros::NodeHandle nh;

  ros::Publisher chatter_pub = nh.advertise<geometry_msgs::Twist>("Control", 25);
  ros::Subscriber sub = nh.subscribe("Boat_pos", 25, chatter_callback);
  geometry_msgs::Twist msg;
  double x_w = 0.0, y_w = 0.0;   //point de suivie

  ros::Rate loop_rate(25);
  while (ros::ok())
  {
    double T = atan2(y_w - y,x_w - x);
    double dtheta = theta-T;
    double e=2.0* atan(tan(dtheta/2.0));
    double u = 0.0;
    if (abs(e) > M_PI/4.0){
      u = 1;
    }
    else{
      u = K * e;// dent de scie;
    }

    
    msg.angular.z = u;
    chatter_pub.publish(msg);

    ros::spinOnce();

    loop_rate.sleep();
  }

  return 0;
}
