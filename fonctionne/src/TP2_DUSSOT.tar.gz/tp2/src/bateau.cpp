#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64MultiArray.h"
#include "geometry_msgs/PoseStamped.h"
#include "visualization_msgs/Marker.h"
#include "tf/tf.h"
#include <cmath>
#include <array>
double u= 0.0;
using namespace std;

void Euler(vector<double> &x){
  double dt = 1.0/5;
  int v = 1;

  x[0] += v * cos(x[2]) * dt;
  x[1] += v * sin(x[2]) * dt;

  x[2] += u * dt;
  x[2] = 2.0*atan(tan(x[2]*0.5));
}

void chatter_callback(const geometry_msgs::Twist::ConstPtr &msg)
{
  u = msg->angular.z;
  ROS_INFO("dtheta = %f", msg->angular.z);
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "tourelle");
  ros::NodeHandle nh;

  ros::Publisher chatter_pub = nh.advertise<geometry_msgs::PoseStamped>("Boat_pos", 1000);
  ros::Subscriber sub = nh.subscribe("Control", 10, chatter_callback);

  ros::Rate loop_rate(25);
  vector<double> x = {0.0,0.0,0.0};

  geometry_msgs::PoseStamped msg;
  msg.header.frame_id = "map";
  tf::Quaternion q;

//  nh.param<double>("nom_du_parameter", varibale, valeur_par_defaut);//question prof
  nh.param<double>("position_x", x[0], 0.0);
  nh.param<double>("position_y", x[1], 0.0);
  std::string ns = ros::this_node::getNamespace();
  ros::Publisher vis_pub = nh.advertise<visualization_msgs::Marker>( "visualization_marker", 1 );
  visualization_msgs::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = ns;
  marker.id = 0;
  marker.type = visualization_msgs::Marker::MESH_RESOURCE;
  marker.action = visualization_msgs::Marker::ADD;

  marker.scale.x = 1;
  marker.scale.y = 1;
  marker.scale.z = 1;
  marker.color.a = 1.0; // alpha = transparence
  marker.color.r = 1.0;
  marker.color.g = 1.0;
  marker.color.b = 1.0;
  marker.mesh_resource = "package://tp2/meshs/boat.dae";

  while (ros::ok())
  {

    Euler(x);
    //printf("en dehors : %f\n",x[2]);

    msg.pose.position.x = x[0];          //publi x y
    msg.pose.position.y = x[1];
    msg.pose.position.z = 0;
    q.setRPY(0,0,x[2]);
    tf::quaternionTFToMsg(q,msg.pose.orientation); //publi orientation sous forme quaternion
    msg.header.stamp = ros::Time::now();
    marker.pose = msg.pose;// ToDo
    chatter_pub.publish(msg);
    vis_pub.publish( marker );

    ros::spinOnce();

    loop_rate.sleep();
  }

  return 0;
}
